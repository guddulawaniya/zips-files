package com.example.complaintapplication;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class HttpPostExample {

    public static void main(String[] args) {
        try {
            // Specify the URL to which you want to send the POST request
            String url = "https://example.com/api";

            // Create a URL object
            URL obj = new URL(url);

            // Open a connection using HttpURLConnection
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();

            // Set the request method to POST
            con.setRequestMethod("POST");

            // Enable input/output streams
            con.setDoOutput(true);
            con.setDoInput(true);

            // Set the request headers
            con.setRequestProperty("Content-Type", "application/json");

            // Create the POST data
            String postData = "{\"key1\":\"value1\",\"key2\":\"value2\"}";

            // Get the output stream of the connection
            try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
                // Write the POST data to the stream
                wr.write(postData.getBytes(StandardCharsets.UTF_8));
            }

            // Get the response code
            int responseCode = con.getResponseCode();
            System.out.println("Response Code: " + responseCode);

            // Read the response from the server
            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                String inputLine;
                StringBuilder response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }

                // Print the response
                System.out.println("Response: " + response.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
