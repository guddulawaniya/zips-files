package com.example.complaintapplication;

import android.app.Dialog;
import android.content.Context;
import android.view.Window;

public class LoaderDialog {
    private final Dialog dialog;

    public LoaderDialog(Context context) {
        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.loader_layout);
    }

    public void show() {
        dialog.show();
    }

    public void dismiss() {
        dialog.dismiss();
    }
}
