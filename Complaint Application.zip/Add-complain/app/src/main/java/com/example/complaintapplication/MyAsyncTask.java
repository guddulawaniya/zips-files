package com.example.complaintapplication;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MyAsyncTask extends AsyncTask<String, Void, String> {

    private static final String TAG = "MyAsyncTask";

    @Override
    protected String doInBackground(String... params) {
        String urlString = params[0];
        String postData = params[1];

        try {
            URL url = new URL(urlString);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

            // Set the request method to POST
            urlConnection.setRequestMethod("POST");

            // Enable input/output streams
            urlConnection.setDoInput(true);
            urlConnection.setDoOutput(true);

            // Set content type
            urlConnection.setRequestProperty("Content-Type", "application/json");

            // Write the data to the output stream
            OutputStream out = new BufferedOutputStream(urlConnection.getOutputStream());
            out.write(postData.getBytes());
            out.flush();
            out.close();

            // Get the response
            InputStream in = urlConnection.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

            // Close the connections
            in.close();
            urlConnection.disconnect();

            return response.toString();
        } catch (IOException e) {
            Log.e(TAG, "Error during HTTP POST request", e);
            return null;
        }
    }

    @Override
    protected void onPostExecute(String result) {
        // Handle the result here
        if (result != null) {
            Log.d(TAG, "Response: " + result);
        } else {
            Log.e(TAG, "Error: No response received");
        }
    }
}
