package com.example.complaintapplication;

import static android.content.Context.MODE_PRIVATE;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


public class ProfileFragment extends AppCompatActivity {


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_profile);

        TextView clientid = findViewById(R.id.clientid);
        TextView termcondition = findViewById(R.id.termcondition);
        TextView logoutbutton = findViewById(R.id.logoutbutton);
        ImageView backbutton = findViewById(R.id.backbutton);
        TextView status = findViewById(R.id.status);
        TextView close_complain = findViewById(R.id.close_complain);
        close_complain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileFragment.this, StatusFragment.class);
                startActivity(intent);
            }
        });  status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileFragment.this, StatusFragment.class);
                startActivity(intent);
            }
        });

        logoutbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor preferences = getSharedPreferences("logindata",MODE_PRIVATE).edit();
                preferences.clear();
                preferences.commit();
                Intent intent = new Intent(ProfileFragment.this, login_Actvity.class);
                startActivity(intent);
                finish();
            }
        });

        termcondition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileFragment.this, webview_activity.class);
                startActivity(intent);
            }
        });
        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileFragment.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        SharedPreferences preferences = getSharedPreferences("logindata",MODE_PRIVATE);
        String mobilenumber = preferences.getString("number",null);
        clientid.setText(mobilenumber);

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(ProfileFragment.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}