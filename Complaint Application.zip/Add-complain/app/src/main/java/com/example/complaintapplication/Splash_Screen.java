package com.example.complaintapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;


public class Splash_Screen extends AppCompatActivity {

    String mobilenumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        ImageView image = findViewById(R.id.logo);

        Animation ani = AnimationUtils.loadAnimation(this,R.anim.imageanimation);
        image.startAnimation(ani);

        SharedPreferences preferences = getSharedPreferences("logindata",MODE_PRIVATE);
        mobilenumber = preferences.getString("number",null);

         if (mobilenumber!=null)
         {
             Intent intent = new Intent(Splash_Screen.this, MainActivity.class);
             startActivity(intent);
             finish();
         }
         else
         {
             new Handler().postDelayed(new Runnable() {
                 @Override
                 public void run() {

                     startActivity(new Intent(getApplicationContext(), login_Actvity.class));
                     overridePendingTransition(R.anim.right_in_activity,R.anim.left_out_activity);
                     finish();
                 }
             },2000);
         }


    }
}