package com.example.complaintapplication;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class complaint_Form_Activity extends AppCompatActivity {

    ArrayList<String> countrylist;
    ArrayList<String> statelist;
    ArrayList<String> brandlist;
    ArrayList<String> partynamelist;
    ArrayList<String> citylist;
    ArrayList<String> complainlist;
    AutoCompleteTextView partyname, state, city, brand, location, country, complain;
    TextInputEditText address, emailid, phonenumber, partycode;
    TextInputLayout addresslayout, emailidlayout, phonenumberlayout, partycodelayout;
    Button saveButton;
    ProgressDialog mProgressDialog;
    AlertDialog alertDialog;
    LoaderDialog loaderDialog;

    String partynameindex, brandindex, locationindex, countyindex, stateindex, cityindex;
    int partyid, cityid, stateid, brandid;

    String storecode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaint_form);

        partyname = findViewById(R.id.partyName);
        location = findViewById(R.id.location);
        brand = findViewById(R.id.brand);
        partycode = findViewById(R.id.partyCode);
        address = findViewById(R.id.address);
        city = findViewById(R.id.city);
        state = findViewById(R.id.state);
        country = findViewById(R.id.country);
        emailid = findViewById(R.id.emailId);
        phonenumber = findViewById(R.id.phone);
        complain = findViewById(R.id.complaint);
        saveButton = findViewById(R.id.saveButton);
        loaderDialog = new LoaderDialog(this);

        AlertDialog.Builder builder = new AlertDialog.Builder(complaint_Form_Activity.this);

        builder.setMessage("Thank you for Feedback We are try to resolve your problem very soon \n your feedback is valueble for us ");

        builder.setTitle("Complain");

        builder.setCancelable(false);


        builder.setPositiveButton("Yes", (DialogInterface.OnClickListener) (dialog, which) -> {
           onBackPressed();
        });

        Intent intent = getIntent();
        storecode = intent.getStringExtra("storecode");
        partyid = intent.getIntExtra("partyname", 0);
        cityid = intent.getIntExtra("city", 0);
        stateid = intent.getIntExtra("state", 0);
        brandid = intent.getIntExtra("brand", 0);


        partynameindex = String.valueOf(partyid);
        cityindex = String.valueOf(cityid);
        stateindex = String.valueOf(stateid);
        brandindex = String.valueOf(brandid);


        partycode.setText(storecode);


        brandlist = new ArrayList<>();
        countrylist = new ArrayList<>();
        statelist = new ArrayList<>();
        partynamelist = new ArrayList<>();
        citylist = new ArrayList<>();
        complainlist = new ArrayList<>();
        alertDialog = builder.create();


        //layouts
        addresslayout = findViewById(R.id.addresslayout);
        emailidlayout = findViewById(R.id.emailidlayout);
        phonenumberlayout = findViewById(R.id.phonenumberlayout);
        partycodelayout = findViewById(R.id.partycodelayout);


        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setTitle("Please Wait");
        mProgressDialog.setMessage("Loading..");


        partyname.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                                    long arg3) {
                partynameindex = String.valueOf(arg2 + 1);

            }
        });
        brand.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                                    long arg3) {
                brandindex = String.valueOf(arg2 + 1);

            }
        });
        country.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                                    long arg3) {
                countyindex = String.valueOf(arg2 + 1);

            }
        });
        location.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                                    long arg3) {
                locationindex = String.valueOf(arg2 + 1);

            }
        });
        state.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                                    long arg3) {
                stateindex = String.valueOf(arg2 + 1);

            }
        });
        city.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                                    long arg3) {
                cityindex = String.valueOf(arg2 + 1);

            }
        });


        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!partyname.getText().toString().isEmpty() && !partycode.getText().toString().isEmpty() && !address.getText().toString().isEmpty() &&
                        !city.getText().toString().isEmpty() && !emailid.getText().toString().isEmpty() && !phonenumber.getText().toString().isEmpty()) {

                    postDataUsingVolley();

                } else if (partycode.getText().toString().isEmpty()) {
                    errorShowFunction(partycodelayout, partycode);
                } else if (address.getText().toString().isEmpty()) {
                    errorShowFunction(addresslayout, address);
                } else if (emailid.getText().toString().isEmpty()) {
                    errorShowFunction(emailidlayout, emailid);
                } else if (phonenumber.getText().toString().isEmpty()) {
                    errorShowFunction(phonenumberlayout, phonenumber);
                }
            }
        });


        getdropdondata(config_file.Base_url + "getcountry.php", countrylist, country, -1);
        getdropdondata(config_file.Base_url + "gatestate.php", statelist, state, stateid);
        getdropdondata(config_file.Base_url + "brand.php", brandlist, brand, brandid);
        getdropdondata(config_file.Base_url + "getparty.php", partynamelist, partyname, partyid);
        getdropdondata(config_file.Base_url + "getcity.php", citylist, city, cityid);
        getdropdondata(config_file.Base_url + "getcomplaintdescription.php", complainlist, complain, -1);

        ArrayAdapter<String> partnameAdapter = new ArrayAdapter<>(this, R.layout.list_layout, partynamelist);
        partyname.setThreshold(10);
        partyname.setDropDownBackgroundResource(R.color.dialog_bg);
        partyname.setAdapter(partnameAdapter);

        ArrayAdapter<String> stateadapter = new ArrayAdapter<>(this, R.layout.list_layout, statelist);
        state.setThreshold(10);
        state.setDropDownBackgroundResource(R.color.dialog_bg);
        state.setAdapter(stateadapter);

        ArrayAdapter<String> citystateadapter = new ArrayAdapter<>(this, R.layout.list_layout, countrylist);
        country.setThreshold(10);
        country.setDropDownBackgroundResource(R.color.dialog_bg);
        country.setAdapter(citystateadapter);

        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(this, R.layout.list_layout, citylist);
        city.setDropDownBackgroundResource(R.color.dialog_bg);
        city.setAdapter(cityAdapter);

        ArrayAdapter<String> brandAdapter = new ArrayAdapter<>(complaint_Form_Activity.this, R.layout.list_layout, brandlist);
        brand.setDropDownBackgroundResource(R.color.dialog_bg);
        brand.setAdapter(brandAdapter);


        ArrayAdapter<String> locationAdapter = new ArrayAdapter<>(this, R.layout.list_layout, citylist);
        location.setThreshold(10);
        location.setDropDownBackgroundResource(R.color.dialog_bg);
        location.setAdapter(locationAdapter);

        ArrayAdapter<String> complainAdapter = new ArrayAdapter<>(this, R.layout.list_layout, complainlist);
        complain.setThreshold(10);
        complain.setDropDownBackgroundResource(R.color.dialog_bg);
        complain.setAdapter(complainAdapter);

    }


    void errorShowFunction(TextInputLayout layout, TextInputEditText text) {
        layout.startAnimation(AnimationUtils.loadAnimation(getApplication(), R.anim.shake_text));
        layout.setBoxStrokeErrorColor(ColorStateList.valueOf(Color.RED));
        layout.setErrorTextColor(ColorStateList.valueOf(Color.RED));
        layout.setError("Required*");
        text.requestFocus();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void postDataUsingVolley() {
        String url = config_file.Base_url + "createcomplaint.php";
        mProgressDialog.show();
        LocalTime currentTime = LocalTime.now();
        LocalDate currentDate = LocalDate.now();


        String nnumberc = new DecimalFormat("000000000").format(new Random().nextInt(999999999));
        String complainnumber = "SM"+nnumberc;

        RequestQueue queue = Volley.newRequestQueue(complaint_Form_Activity.this);

        StringRequest request = new StringRequest(Request.Method.POST, url, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                mProgressDialog.dismiss();
                Toast.makeText(complaint_Form_Activity.this, "successfully Added Complaint", Toast.LENGTH_SHORT).show();
                alertDialog.show();
            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mProgressDialog.dismiss();
                Toast.makeText(complaint_Form_Activity.this, "Something want wrong  ", Toast.LENGTH_SHORT).show();
            }

        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("compliantnumber", complainnumber);
                params.put("date_s", String.valueOf(currentDate));
                params.put("time_s", String.valueOf(currentTime));
                params.put("party_id", partynameindex);
                params.put("location_id", locationindex);
                params.put("brand_name", brandindex);
                params.put("party_code", partycode.getText().toString());
                params.put("party_address", address.getText().toString());
                params.put("cityid", cityindex);
                params.put("state", stateindex);
                params.put("country", countyindex);
                params.put("email", emailid.getText().toString());
                params.put("phone", phonenumber.getText().toString());
                params.put("description", complain.getText().toString());
                return params;
            }
        };
        queue.add(request);
    }
    private void getdropdondata(String registrationURL, ArrayList<String> list, AutoCompleteTextView textView, int id) {
        loaderDialog.show();

        class registration extends AsyncTask<String, String, String> {

            @Override
            protected void onPostExecute(String s) {

                try {
                    JSONArray object = new JSONArray(s);
                    int i=0;

                    while (i<object.length()) {
                        JSONObject object1 = object.getJSONObject(i);
                        String brandname = object1.getString("name");
                        list.add(brandname);
                        if (i==id) textView.setText(brandname);
                        ++i;
                    }

                    loaderDialog.dismiss();

                } catch (JSONException e) {
                    throw new RuntimeException(e);

                }
                super.onPostExecute(s);
            }

            @Override
            protected String doInBackground(String... param) {

                try {
                    URL url = new URL(param[0]);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    return br.readLine();
                } catch (Exception ex) {
                    return ex.getMessage();
                }

            }


        }

        registration obj = new registration();
        obj.execute(registrationURL);


    }
}