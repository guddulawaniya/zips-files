package com.example.complaintapplication;

public class config_file {

    public static final String Base_url = "https://dummy-crm.raghaw.in/api/";
    public static final String Dammy_Base_url = "https://dummy-crm.raghaw.in/api/";
}
