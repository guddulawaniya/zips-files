package com.example.complaintapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class detail_Adapter extends RecyclerView.Adapter<detail_Adapter.viewholder> {

    ArrayList<complaintModule> list;

    public detail_Adapter(ArrayList<complaintModule> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.inner_recyclerview_card,parent,false);
        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position) {
        complaintModule module = list.get(position);
        holder.staticText.setText(module.getStaticText());
        holder.dynamicText.setText(module.getDynamicText());


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class viewholder extends RecyclerView.ViewHolder {
        TextView staticText, dynamicText;

        public viewholder(@NonNull View itemView) {
            super(itemView);
            staticText = itemView.findViewById(R.id.staticText);
            dynamicText = itemView.findViewById(R.id.dynamicText);
        }
    }
}

