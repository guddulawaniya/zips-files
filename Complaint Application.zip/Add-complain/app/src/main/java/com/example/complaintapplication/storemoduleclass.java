package com.example.complaintapplication;

public class storemoduleclass {
    String code;
    int party_id,city_id,state_id,brand_id;

    public storemoduleclass(String code, int party_id, int city_id, int state_id, int brand_id) {
        this.code = code;
        this.party_id = party_id;
        this.city_id = city_id;
        this.state_id = state_id;
        this.brand_id = brand_id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getParty_id() {
        return party_id;
    }

    public void setParty_id(int party_id) {
        this.party_id = party_id;
    }

    public int getCity_id() {
        return city_id;
    }

    public void setCity_id(int city_id) {
        this.city_id = city_id;
    }

    public int getState_id() {
        return state_id;
    }

    public void setState_id(int state_id) {
        this.state_id = state_id;
    }

    public int getBrand_id() {
        return brand_id;
    }

    public void setBrand_id(int brand_id) {
        this.brand_id = brand_id;
    }
}
