package com.example.complaintapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.widget.TintableCheckedTextView;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class typesCreate_complaints extends AppCompatActivity {

    AutoCompleteTextView brand,city,partyname,state,storecode;
    ArrayList<String> statelist;
    ArrayList<String> brandlist;
    ArrayList<String> partynamelist;
    ArrayList<String> citylist;
    ArrayList<String> drondownlistStorecode;

    LinearLayout storelayoutlinear,myLayout;
    private static final int CAMERA_PERMISSION_REQUEST = 1001;
    LoaderDialog loaderDialog;
    int storeindex;
    TextInputLayout storelayout,brandlayout,citylayout,statelayout,partylayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_types_create_complaints);

        state = findViewById(R.id.state);
        partyname = findViewById(R.id.partyName);
        city = findViewById(R.id.city);

        brand = findViewById(R.id.brand);
        ImageView Qrcode = findViewById(R.id.qrcodeimage);
        myLayout = findViewById(R.id.linearLayout);
        storelayoutlinear = findViewById(R.id.storelayoutlinear);
        citylayout = findViewById(R.id.citylayout);
        statelayout = findViewById(R.id.statelayout);
        partylayout = findViewById(R.id.partnamelayout);
        brandlayout = findViewById(R.id.brandlayout);
        storelayout = findViewById(R.id.storelayouttext);
         storecode = findViewById(R.id.storetextinput);
        Button submitbutton = findViewById(R.id.submitbutton);


        hiddenError(brandlayout,brand);
        hiddenError(partylayout,partyname);
        hiddenError(statelayout,state);
        hiddenError(citylayout,city);

        loaderDialog = new LoaderDialog(this);



        statelist = new ArrayList<>();
        partynamelist = new ArrayList<>();
        citylist = new ArrayList<>();
        brandlist = new ArrayList<>();
        drondownlistStorecode = new ArrayList<>();

        getdatastorecode(config_file.Dammy_Base_url + "getstorecode.php");
        getdropdondata(config_file.Base_url + "gatestate.php",statelist);
        getdropdondata(config_file.Base_url + "brand.php",brandlist);
        getdropdondata(config_file.Base_url + "getparty.php",partynamelist);
        getdropdondata(config_file.Base_url + "getcity.php",citylist);


        ArrayAdapter<String> partnameAdapter = new ArrayAdapter<>(this, R.layout.list_layout, partynamelist);
        partyname.setThreshold(10);
        partyname.setDropDownBackgroundResource(R.color.dialog_bg);
        partyname.setAdapter(partnameAdapter);

        RadioButton checkbox1 = findViewById(R.id.checkBox1);
        RadioButton checkbox2 = findViewById(R.id.checkBox2);
        checkbox1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (storelayout.getVisibility()==View.VISIBLE)
                {
                    myLayout.setVisibility(View.VISIBLE);
                    storelayoutlinear.setVisibility(View.GONE);
                }
            }
        });
        checkbox2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myLayout.getVisibility()==View.VISIBLE)
                {
                    myLayout.setVisibility(View.GONE);
                    storelayoutlinear.setVisibility(View.VISIBLE);
                }
            }
        });

        Qrcode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkCameraPermissionAndOpen();
            }
        });

        storecode.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                                    long arg3) {
                storeindex = arg2+1;

            }
        });

        ArrayAdapter<String> stateadapter = new ArrayAdapter<>(this, R.layout.list_layout, statelist);
        state.setThreshold(10);
        state.setDropDownBackgroundResource(R.color.dialog_bg);
        state.setAdapter(stateadapter);

        ArrayAdapter<String> storelist = new ArrayAdapter<>(this, R.layout.list_layout, drondownlistStorecode);
        storecode.setThreshold(10);
        storecode.setDropDownBackgroundResource(R.color.dialog_bg);
        storecode.setAdapter(storelist);


        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(this, R.layout.list_layout, citylist);
        city.setThreshold(10);
        city.setDropDownBackgroundResource(R.color.dialog_bg);
        city.setAdapter(cityAdapter);

        ArrayAdapter<String> brandAdapter = new ArrayAdapter<>(this, R.layout.list_layout, brandlist);
        brand.setDropDownBackgroundResource(R.color.dialog_bg);
        brand.setAdapter(brandAdapter);

        storecode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                storelayout.setErrorEnabled(false);

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });



        submitbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkbox1.isChecked())
                {
                    if (!brand.getText().toString().isEmpty()&&!partyname.getText().toString().isEmpty() && !state.getText().toString().isEmpty() && !city.getText().toString().isEmpty())
                    {
                        Toast.makeText(typesCreate_complaints.this, "Please Wait loading data", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(typesCreate_complaints.this, complaint_Form_Activity.class);
                        startActivity(intent);
                        finish();

                    }
                    else if (brand.getText().toString().isEmpty())
                    {
                        errorshow(brandlayout,brand);
                    }
                    else if (partyname.getText().toString().isEmpty())
                    {
                        errorshow(partylayout,partyname);
                    }
                    else if (state.getText().toString().isEmpty())
                    { errorshow(statelayout,state);

                    }else
                    {

                        errorshow(citylayout,city);
                    }
                }
                else
                {

                    if (!storecode.getText().toString().isEmpty())
                    {

                        getcomplaindata(config_file.Dammy_Base_url + "createstorecomplate.php?id="+storeindex);


                    }
                    else
                    {
                        storelayout.startAnimation(AnimationUtils.loadAnimation(getApplication(), R.anim.shake_text));
                        storelayout.setBoxStrokeErrorColor(ColorStateList.valueOf(Color.RED));
                        storelayout.setErrorTextColor(ColorStateList.valueOf(Color.RED));
                        storelayout.setError("Required*");
                        storecode.requestFocus();
                    }
                }

            }
        });


    }
     void errorshow(TextInputLayout layout, AutoCompleteTextView text) {
        layout.startAnimation(AnimationUtils.loadAnimation(getApplication(), R.anim.shake_text));
        layout.setBoxStrokeErrorColor(ColorStateList.valueOf(Color.RED));
        layout.setErrorTextColor(ColorStateList.valueOf(Color.RED));
        layout.setError("Required*");
        text.requestFocus();
    }

    void hiddenError(TextInputLayout layout, AutoCompleteTextView text)
    {
        text.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                layout.setErrorEnabled(false);

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void checkCameraPermissionAndOpen() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            // Request the camera permission if not granted
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.CAMERA},
                    CAMERA_PERMISSION_REQUEST);
        } else {
            // Open the camera if the permission is already granted
            openCamera();
        }
    }

    private void openCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (cameraIntent.resolveActivity(getPackageManager()) != null) {
            // Start the camera activity
            startActivityForResult(cameraIntent, CAMERA_PERMISSION_REQUEST);
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CAMERA_PERMISSION_REQUEST && resultCode == RESULT_OK) {
            Intent intent = new Intent(typesCreate_complaints.this, complaint_Form_Activity.class);
            startActivity(intent);
            finish();

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Camera permission granted, open the camera
                openCamera();
            }
        }
    }


    private void getcomplaindata(String registrationURL) {

        loaderDialog.show();
        class registration extends AsyncTask<String, String, String> {


            @Override
            protected void onPostExecute(String s) {

                try {

                    loaderDialog.dismiss();
                        JSONObject object1 = new JSONObject(s);
                        String storecode = object1.getString("code");
                        int party_id = object1.getInt("party_id");
                        int city_id = object1.getInt("city_id");
                        int state_id = object1.getInt("state_id");
                        int brand_id = object1.getInt("brand_id");



                    Intent intent = new Intent(typesCreate_complaints.this, complaint_Form_Activity.class);
                    intent.putExtra("storecode",storecode);
                    intent.putExtra("partyname",party_id);
                    intent.putExtra("city",city_id);
                    intent.putExtra("state",state_id);
                    intent.putExtra("brand",brand_id);
                    startActivity(intent);
                    finish();

                } catch (JSONException e) {
                    throw new RuntimeException(e);

                }
                super.onPostExecute(s);
            }

            @Override
            protected String doInBackground(String... param) {

                try {
                    URL url = new URL(param[0]);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    return br.readLine();
                } catch (Exception ex) {
                    return ex.getMessage();
                }

            }
        }
        registration obj = new registration();
        obj.execute(registrationURL);


    }
    private void getdatastorecode(String registrationURL) {

        loaderDialog.show();

        class registration extends AsyncTask<String, String, String> {

            @Override
            protected void onPostExecute(String s) {

                try {
                    loaderDialog.dismiss();
                    JSONArray object = new JSONArray(s);

                    for (int i = 0; i < object.length(); ++i) {
                        JSONObject object1 = object.getJSONObject(i);
                        String storecode = object1.getString("code");
                        drondownlistStorecode.add(storecode);
                    }


                } catch (JSONException e) {
                    throw new RuntimeException(e);

                }
                super.onPostExecute(s);
            }

            @Override
            protected String doInBackground(String... param) {

                try {
                    URL url = new URL(param[0]);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    return br.readLine();
                } catch (Exception ex) {
                    return ex.getMessage();
                }

            }
        }
        registration obj = new registration();
        obj.execute(registrationURL);


    }

    private void getdropdondata(String registrationURL,ArrayList<String> list) {

        class registration extends AsyncTask<String, String, String> {

            @Override
            protected void onPostExecute(String s) {

                try {
                    JSONArray object = new JSONArray(s);


                    for (int i = 0; i < object.length(); ++i) {
                        JSONObject object1 = object.getJSONObject(i);
                        String name = object1.getString("name");
                        list.add(name);
                    }

                } catch (JSONException e) {
                    throw new RuntimeException(e);

                }
                super.onPostExecute(s);
            }

            @Override
            protected String doInBackground(String... param) {

                try {
                    URL url = new URL(param[0]);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    return br.readLine();
                } catch (Exception ex) {
                    return ex.getMessage();
                }
            }
        }
        registration obj = new registration();
        obj.execute(registrationURL);
    }
}