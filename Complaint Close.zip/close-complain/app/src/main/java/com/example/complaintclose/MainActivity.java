package com.example.complaintclose;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Home_Fragment fragment1 = new Home_Fragment();
        replaceFragment(fragment1);

        CardView profile = findViewById(R.id.profile);
        Toolbar toolbar = findViewById(R.id.toolbar);

        TextView logout = findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,login_Actvity.class));
                finish();
            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DrawerLayout drawerlayout = findViewById(R.id.drawerlayout);

                drawerlayout.openDrawer(Gravity.LEFT);
            }
        });


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnItemSelectedListener(item -> {

            if (R.id.home==item.getItemId())
            {
                toolbar.setVisibility(View.VISIBLE);
                Home_Fragment fragment = new Home_Fragment();
                replaceFragment(fragment);
            }
            else if (R.id.status==item.getItemId())
            {
                toolbar.setVisibility(View.VISIBLE);
                StatusFragment statusFragment = new StatusFragment();
                replaceFragment(statusFragment);
            }
            else
            {
                toolbar.setVisibility(View.GONE);
                ProfileFragment profileFragment = new ProfileFragment();
                replaceFragment(profileFragment);
            }

            return true;
        });
    }

    private void replaceFragment(Fragment fragment) {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.framelayout, fragment)
            .commit();


    }
}