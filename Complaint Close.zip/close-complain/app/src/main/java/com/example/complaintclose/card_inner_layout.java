package com.example.complaintclose;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class card_inner_layout extends AppCompatActivity {


    ArrayList<complaintModule> list;
     private TextView staus,complain,createdate,partyname,partycode,brand,address,emailid,mobileno;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.card_inner_layout);

        list = new ArrayList<>();


        Intent intent = getIntent();
        String statustext = intent.getStringExtra("status");

        RecyclerView datarecyclerview = findViewById(R.id.datarecyclerview);

        String complainno = intent.getStringExtra("comlainno");
        String status = String.valueOf(intent.getIntExtra("status", 0));
        String createdate = intent.getStringExtra("date");
        String emailid = intent.getStringExtra("emailid");
        String mobileno = intent.getStringExtra("mobileno");
        String partycode = intent.getStringExtra("partycode");
        String partyname = intent.getStringExtra("partyname");
        String complainreason = intent.getStringExtra("complainreason");
        String city = intent.getStringExtra("city");
        String state = intent.getStringExtra("state");
        String country = intent.getStringExtra("country");
        String address = intent.getStringExtra("address");
        String groupname = intent.getStringExtra("groupname");
        String itemname = intent.getStringExtra("itemname");
        String itemquantity = intent.getStringExtra("quantity");
        String serialno = intent.getStringExtra("serialno");
        String tdsin = intent.getStringExtra("tsdin");
        String tdsout = intent.getStringExtra("tdsout");


       ImageView backArrow =findViewById(R.id.backarrow);
       Button okaybutton =findViewById(R.id.okaybutton);
       backArrow.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               onBackPressed();
           }
       });

        okaybutton.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               startActivity(new Intent(card_inner_layout.this, complaint_Form_Activity.class));

           }
       });

        if (complainno != null && !complainno.equals("null"))
            list.add(new complaintModule("Complain NO", complainno));
        if (status != null && !status.equals("null"))
            list.add(new complaintModule("Status", status));
        if (createdate != null && !createdate.equals("null"))
            list.add(new complaintModule("Create Date & Time", createdate));
        if (emailid != null && !emailid.equals("null"))
            list.add(new complaintModule("Email Id", emailid));
        if (mobileno != null && !mobileno.equals("null"))
            list.add(new complaintModule("Mobile No", mobileno));
        if (partycode != null && !partycode.equals("null"))
            list.add(new complaintModule("Party Code", partycode));
        if (partyname != null && !partyname.equals("null"))
            list.add(new complaintModule("Party Name", partyname));
        if (complainreason != null && !complainreason.equals("null"))
            list.add(new complaintModule("Complain Reason", complainreason));
        if (city != null && !city.equals("null")) list.add(new complaintModule("City", city));
        if (state != null && !state.equals("null")) list.add(new complaintModule("State", state));
        if (country != null && !country.equals("null"))
            list.add(new complaintModule("Country", country));
        if (address != null && !address.equals("null"))
            list.add(new complaintModule("Address", address));
        if (groupname != null && !groupname.equals("null"))
            list.add(new complaintModule("Group Name", groupname));
        if (itemname != null && !itemname.equals("null"))
            list.add(new complaintModule("Item Name", itemname));
        if (tdsin != null && !tdsin.equals("null")) list.add(new complaintModule("TDS IN", tdsin));
        if (tdsout != null && !tdsout.equals("null"))
            list.add(new complaintModule("TDS OUT", tdsout));

        datarecyclerview.setLayoutManager(new LinearLayoutManager(this));
        detail_Adapter detailAdapter = new detail_Adapter(list);
        datarecyclerview.setAdapter(detailAdapter);




    }
}