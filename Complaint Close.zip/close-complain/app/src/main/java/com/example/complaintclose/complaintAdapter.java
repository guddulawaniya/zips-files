package com.example.complaintclose;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class complaintAdapter extends RecyclerView.Adapter<complaintAdapter.viewholder> {

    List<complaintModule> list;
    Context context;

    public complaintAdapter(List<complaintModule> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.complain_status_card, parent, false);
        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position) {
        complaintModule module = list.get(position);
        holder.comaplaintno.setText(module.getComplaintNO());
        holder.date.setText(module.getDate());
        holder.partyname.setText(module.getPartyname());
        holder.address.setText(module.getLocation());

        int completeid = module.getStatus();

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context,card_inner_layout.class);
                intent.putExtra("comlainno",module.getComplaintNO());
                intent.putExtra("date",module.getDate());
                intent.putExtra("status",module.getStatus());
                intent.putExtra("partyname",module.getPartyname());
                intent.putExtra("address",module.getLocation());
                context.startActivity(intent);

            }
        });

        if (completeid == 1) {
            holder.statusicon.setImageResource(R.drawable.complete_icon);
            holder.status.setBackgroundColor(Color.parseColor("#1EA323"));
            holder.status.setText("Closed");
        } else if (completeid == 2) {
            holder.statusicon.setImageResource(R.drawable.raject_icon);
            holder.status.setBackgroundColor(Color.parseColor("#D11414"));
            holder.status.setText("Rajected");

        } else {
            holder.statusicon.setImageResource(R.drawable.pening_icon);
            holder.status.setBackgroundColor(Color.parseColor("#FFD041"));
            holder.status.setText("Pending");

        }


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class viewholder extends RecyclerView.ViewHolder {
        TextView comaplaintno, partyname, date, address, status;
        ImageView statusicon;

        public viewholder(@NonNull View itemView) {
            super(itemView);
            comaplaintno = itemView.findViewById(R.id.complainnumber);
            partyname = itemView.findViewById(R.id.complaintNo);
            date = itemView.findViewById(R.id.date);
            address = itemView.findViewById(R.id.address);
            status = itemView.findViewById(R.id.status);
            statusicon = itemView.findViewById(R.id.statusicon);
        }
    }
}
