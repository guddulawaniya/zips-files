package com.example.complaintclose;

public class complaintModule {

    String complaintNO,date,partyname,location;
    int status;

    String staticText,dynamicText;

    public complaintModule(String staticText, String dynamicText) {
        this.staticText = staticText;
        this.dynamicText = dynamicText;
    }

    public complaintModule(String complaintNO, String date, String partyname, String location, int status) {
        this.complaintNO = complaintNO;
        this.date = date;
        this.partyname = partyname;
        this.location = location;
        this.status = status;
    }

    public String getStaticText() {
        return staticText;
    }

    public void setStaticText(String staticText) {
        this.staticText = staticText;
    }

    public String getDynamicText() {
        return dynamicText;
    }

    public void setDynamicText(String dynamicText) {
        this.dynamicText = dynamicText;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getComplaintNO() {
        return complaintNO;
    }

    public void setComplaintNO(String complaintNO) {
        this.complaintNO = complaintNO;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPartyname() {
        return partyname;
    }

    public void setPartyname(String partyname) {
        this.partyname = partyname;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

}
