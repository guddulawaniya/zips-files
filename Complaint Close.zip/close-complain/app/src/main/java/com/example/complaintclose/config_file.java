package com.example.complaintclose;

public class config_file {

    public static final String Base_url = "https://dummy-crm.raghaw.in/api/";
}
