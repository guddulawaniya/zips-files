package com.example.complaintclose;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class secound_update_activity extends AppCompatActivity {

    CardView itemcard;
    Button prebutton, saveButton;

    ImageView backarrow;
    LinearLayout addlinearlayout;
    TextView deletebutton;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.secount_activity_layout);

        TextView addbutton = findViewById(R.id.additembutton);
        deletebutton = findViewById(R.id.deletebutton);
        itemcard = findViewById(R.id.itemcard);
        prebutton = findViewById(R.id.prebutton);
        saveButton = findViewById(R.id.saveButton);
        backarrow = findViewById(R.id.backarrow);
        addlinearlayout = findViewById(R.id.addlinearlayout);

        int lastIndex = addlinearlayout.getChildCount();
        if (lastIndex < 1) deletebutton.setVisibility(View.GONE);

        backarrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        deletebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                deleteitem_for_series_number();

            }
        });
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        prebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        addbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                additemfor_series_number();
            }
        });

    }

    private void animateDuplicateView(View view) {
        // ViewPropertyAnimator example (translation animation)
        Animation animation = new TranslateAnimation(
                Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, -1.0f,
                Animation.RELATIVE_TO_SELF, 0.0f
        );

        animation.setDuration(500);
        animation.setFillAfter(true);
        view.startAnimation(animation);
    }


    void additemfor_series_number() {
        View view = getLayoutInflater().inflate(R.layout.add_series_layout_list, null, false);
        addlinearlayout.addView(view);
        animateDuplicateView(view);
        if (deletebutton.getVisibility() == View.GONE) {
            deletebutton.setVisibility(View.VISIBLE);
        }

    }

    void deleteitem_for_series_number() {

        int lastIndex = addlinearlayout.getChildCount()-1;
        addlinearlayout.removeViewAt(lastIndex);
        if (lastIndex < 1) deletebutton.setVisibility(View.GONE);
    }
}
