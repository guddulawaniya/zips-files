package com.example.complaintclose.Adapters;

public class data_insert_module {
    String gpdata,itemdata,qutydata,serialno;

    public data_insert_module(String gpdata, String itemdata, String qutydata, String serialno) {
        this.gpdata = gpdata;
        this.itemdata = itemdata;
        this.qutydata = qutydata;
        this.serialno = serialno;
    }
}
