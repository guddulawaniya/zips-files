package com.example.deptchatapp.Adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.deptchatapp.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class ChatAdapter extends RecyclerView.Adapter {

    ArrayList<MessagesModule> messagesModules;
    Context context;

    int SENDER_VIEW_TYPE = 1;
    int RECIEVER_VIEW_TYPE = 2;




    public ChatAdapter(ArrayList<MessagesModule> messagesModules, Context context) {
        this.messagesModules = messagesModules;
        this.context = context;

    }

    public ChatAdapter(ArrayList<MessagesModule> messagesModules, Context context, int layId) {
        this.messagesModules = messagesModules;
        this.context = context;
        this.SENDER_VIEW_TYPE = layId;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == SENDER_VIEW_TYPE) {
            View view = LayoutInflater.from(context).inflate(R.layout.sample_message, parent, false);
            return new senderViewholder(view);
        } else {
            View view = LayoutInflater.from(context).inflate(R.layout.sampl_reciever, parent, false);
            return new recieverViewHolder(view);
        }

    }


//    @Override
//    public int getItemViewType(int position) {
//
//        if (messagesModules.get(position).getuId().equals(FirebaseAuth.getInstance().getUid())) {
//            return SENDER_VIEW_TYPE;
//        } else {
//            return RECIEVER_VIEW_TYPE;
//        }
//    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        MessagesModule messagemodule = messagesModules.get(position);

        SharedPreferences preferences = context.getSharedPreferences("login", Context.MODE_PRIVATE);
        String imagetext = preferences.getString("image",null);

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                new AlertDialog.Builder(context)
                        .setTitle("Delete")
                        .setMessage("Are you  sure want to delete this message ")
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int watch) {
                                dialog.dismiss();
                            }
                        }).show();

                return false;
            }
        });

        if (holder.getClass() == senderViewholder.class) {
            ((senderViewholder) holder).senderMsg.setText(messagemodule.getMessage());
            Picasso.get().load(imagetext).into(((senderViewholder) holder).senderimage);
        } else {
            ((recieverViewHolder) holder).recieverMsg.setText(messagemodule.getMessage());
            Picasso.get().load(imagetext).into(((recieverViewHolder) holder).recieverimage);
        }

    }
    @Override
    public int getItemCount() {


        return messagesModules.size();
    }

    public class recieverViewHolder extends RecyclerView.ViewHolder{
        TextView recieverMsg , reciverTime;

        CircleImageView recieverimage;
        public recieverViewHolder(@NonNull View itemView) {
            super(itemView);

            recieverMsg = itemView.findViewById(R.id.recieverText);
            reciverTime = itemView.findViewById(R.id.recieverTime);
            recieverimage = itemView.findViewById(R.id.recieverimage);
        }
    }

    class senderViewholder extends RecyclerView.ViewHolder {
        TextView senderMsg, senderTime;
        CircleImageView senderimage;

        public senderViewholder(@NonNull View itemView) {
            super(itemView);
            senderMsg = itemView.findViewById(R.id.senderText);
            senderTime = itemView.findViewById(R.id.senderTime);
            senderimage = itemView.findViewById(R.id.senderimage);

        }
    }
}
