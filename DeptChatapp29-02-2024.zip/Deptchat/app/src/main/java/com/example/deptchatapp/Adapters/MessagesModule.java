package com.example.deptchatapp.Adapters;

public class MessagesModule {

    String uId,message, mesaageId;
    int lid ;
    long timestamp;

    public MessagesModule(String uId, String message) {
        this.uId = uId;
        this.message = message;
    }

    public MessagesModule(int lid, String message, long timestamp) {
        this.lid = lid;
        this.message = message;
        this.timestamp = timestamp;
    }
    public MessagesModule(){}

    public String getMesaageId(String key) {
        return mesaageId;
    }

    public void setMesaageId(String mesaageId) {
        this.mesaageId = mesaageId;
    }

    public String getuId() {
        return uId;
    }

    public void setuId(String uId) {
        this.uId = uId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getMesaageId() {
        return mesaageId;
    }
}
