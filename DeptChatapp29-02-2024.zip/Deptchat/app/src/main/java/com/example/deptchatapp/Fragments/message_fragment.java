package com.example.deptchatapp.Fragments;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.deptchatapp.Adapters.YourDataModel;
import com.example.deptchatapp.Adapters.maineAdapter;
import com.example.deptchatapp.Ads.ApiService;
import com.example.deptchatapp.R;
import com.example.deptchatapp.chatroom.ChatRoomAdapter;
import com.example.deptchatapp.chatroom.ChatRoomModel;
import com.example.deptchatapp.chatroom.onclick;
import com.example.deptchatapp.show_history_record;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class message_fragment extends Fragment {

    ArrayList<ChatRoomModel> chatroom = new ArrayList<>();
    LinearLayout nodatafound;
    private RecyclerView recView;
    String img, video, name, city;
    private ProgressBar progressDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_message_fragment, container, false);
        CardView call_history = view.findViewById(R.id.call_history);
        CardView likecard = view.findViewById(R.id.likecard);
        nodatafound = view.findViewById(R.id.nodatafound);
        progressDialog = view.findViewById(R.id.progressBar);
        call_history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), show_history_record.class);
                intent.putExtra("title", "Call history");
                startActivity(intent);
            }
        });
        likecard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), show_history_record.class);
                intent.putExtra("title", "I like");
                startActivity(intent);
            }
        });
        recView = view.findViewById(R.id.chatrecyclerview);


        fetchData();

        return view;
    }
    private void fetchData() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://gedgetsworld.in/PM_Kisan_Yojana/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiService apiService = retrofit.create(ApiService.class);

        // Make the API call
        Call<List<YourDataModel>> call = apiService.getData();
        call.enqueue(new Callback<List<YourDataModel>>() {
            @Override
            public void onResponse(Call<List<YourDataModel>> call, Response<List<YourDataModel>> response) {
                if (response.isSuccessful()) {
                    List<YourDataModel> dataList = response.body();

                    // Shuffle the list to display items in random order
                    Collections.shuffle(dataList);
                    if (!dataList.isEmpty()) {
                        YourDataModel randomItem = dataList.get(new Random().nextInt(dataList.size()));
                        img = randomItem.getImg();
                        video = randomItem.getVideo();
                        String[] parts = randomItem.getText().split("-");

                        if (parts.length == 2) {
                            // Extract the name and city
                            name = parts[0];
                            city = parts[1];
                        }
                        Log.d("RandomValues", "img: " + img + ", video: " + video);
                    }

                    progressDialog.setVisibility(View.GONE);




                    ChatRoomAdapter adapter = new ChatRoomAdapter(dataList, getContext());
                    recView.setLayoutManager(new LinearLayoutManager(getContext()));
                    recView.setAdapter(adapter);


                } else {
                    // Handle error
                }

                // Stop refreshing animation
            }

            @Override
            public void onFailure(Call<List<YourDataModel>> call, Throwable t) {
                // Handle failure
                progressDialog.setVisibility(View.GONE);

                // Stop refreshing animati
            }
        });
    }
}