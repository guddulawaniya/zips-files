package com.example.deptchatapp.Fragments;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.airbnb.lottie.LottieAnimationView;
import com.example.deptchatapp.R;


public class meta_fragment extends Fragment {


    Handler handler;
    private int count = 0;
    TextView textviewsetnumber;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_meta, container, false);

         textviewsetnumber = view.findViewById(R.id.loopnumbers);
        LottieAnimationView startbutton = view.findViewById(R.id.startbutton);

        handler = new Handler();

        startCounting(1);
        startbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        return view;
    }
    private void startCounting(final long delayMillis) {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
               count= count+200;
               if (count<27670)
               {
                   textviewsetnumber.setText(String.valueOf(count));
                   // Continue counting with the same delay
                   startCounting(delayMillis);
               }

            }
        }, delayMillis);
    }
    @Override
    public void onDestroy() {
        // Remove any pending callbacks to prevent memory leaks
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}