package com.example.deptchatapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.deptchatapp.Adapters.ChatAdapter;
import com.example.deptchatapp.Adapters.MessagesModule;
import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import de.hdodenhof.circleimageview.CircleImageView;


public class chat_activity extends AppCompatActivity {

    CircleImageView profile_image;
    ImageView back_arrow,videocall;
    TextView userName,textmessage;
    ImageView chatmenu;
    CardView sendsms;
    RecyclerView recyclerView;
    ArrayList<MessagesModule> messagelist;
    LinearLayout chatlocklinearlayout,locklinear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        messagelist = new ArrayList<>();

       String age = new DecimalFormat("18").format(new Random().nextInt(36));
        SharedPreferences preferences = getSharedPreferences("login", Context.MODE_PRIVATE);
        String imagetext = preferences.getString("image",null);
        String name = preferences.getString("name",null);
        String video = preferences.getString("video",null);
        int avaiblecoin = preferences.getInt("coins",0);



        profile_image = findViewById(R.id.profile_image);
        recyclerView = findViewById(R.id.ChatRecyclerView);
        back_arrow = findViewById(R.id.backarrow);
        userName = findViewById(R.id.userName);
        chatmenu = findViewById(R.id.chatmenu);
        videocall = findViewById(R.id.videocall);
        sendsms = findViewById(R.id.sendsms);
        textmessage = findViewById(R.id.textmessage);
        chatlocklinearlayout = findViewById(R.id.chatlocklinearlayout);
        locklinear = findViewById(R.id.locklinear);
        sendsms.setEnabled(false);
        if (avaiblecoin>0)
        {
            chatlocklinearlayout.setVisibility(View.GONE);
            locklinear.setVisibility(View.VISIBLE);

        }
        else {

            locklinear.setVisibility(View.GONE);
            chatlocklinearlayout.setVisibility(View.VISIBLE);
        }
        chatlocklinearlayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(chat_activity.this, plan_activity.class);
                startActivity(intent);

            }
        });



        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        ChatAdapter chatAdapter = new ChatAdapter(messagelist,this);
        recyclerView.setAdapter(chatAdapter);

        chatmenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                diamond_bottomsheet bottomsheet = new diamond_bottomsheet();

                bottomsheet.show(getSupportFragmentManager(), bottomsheet.getTag());
            }
        });
        profile_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(chat_activity.this,details_activity.class);
                intent.putExtra("name",name);
                intent.putExtra("img",imagetext);
                intent.putExtra("age",age);
                startActivity(intent);
            }
        });
        textmessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length()>1)
                {
                    sendsms.setEnabled(true);
                }
                else
                {
                    sendsms.setEnabled(false);
                }


            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        recyclerView.setAdapter();
        sendsms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msgid = new DecimalFormat("000000").format(new Random().nextInt(999999));
                Long timestamp = System.currentTimeMillis();
                if (!textmessage.getText().toString().isEmpty())
                {

                    messagelist.add(new MessagesModule(1,textmessage.getText().toString(),timestamp));
                    textmessage.setText("");
                }
            }
        });

        back_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        videocall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                SharedPreferences preferences = getSharedPreferences("login", MODE_PRIVATE);
                int permincharge = preferences.getInt("perminchage", 0);
                int availablecoin = preferences.getInt("coins", 0);

                if (availablecoin >= permincharge && availablecoin != 0) {
                    SharedPreferences.Editor editor = getSharedPreferences("login", Context.MODE_PRIVATE).edit();
                    editor.putString("video", video);
                    editor.commit();

                    Intent intent = new Intent(chat_activity.this, ConnectionVideoActivity.class);
                    intent.putExtra("video", video);
                    startActivity(intent);
                }
                else
                {
                    Intent intent = new Intent(chat_activity.this, plan_activity.class);
                    startActivity(intent);
                }
            }
        });
        userName.setText(name);
        Picasso.get().load(imagetext).into(profile_image);

    }
}