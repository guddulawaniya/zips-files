package com.example.deptchatapp.chatroom;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;


import com.example.deptchatapp.Adapters.YourDataModel;
import com.example.deptchatapp.BaseActi;
import com.example.deptchatapp.R;
import com.example.deptchatapp.chat_activity;
import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ChatRoomAdapter extends RecyclerView.Adapter<ChatRoomAdapter.chatRoomHolder> {
    public static int PERMISSION_REQUEST_CODE = 200;
    Context context;
    private LayoutInflater inflater;
    private ItemClickCallback itemClickCallback;
    private List<YourDataModel> listData;

    public ChatRoomAdapter(List<YourDataModel> arrayList, Context context) {
        this.listData = arrayList;
        this.context = context;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public chatRoomHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new chatRoomHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.chatroomadapter, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemViewType(int i) {
        return this.listData.size();
    }

    public void onBindViewHolder(chatRoomHolder holder, int i) {

        YourDataModel chatRoomModel = this.listData.get(i);

        String[] parts = chatRoomModel.getText().split("-");

        if (parts.length == 2) {
            // Extract the name and city
            String name = parts[0];
            String location = parts[1];
//            holder.age.setText(new DecimalFormat("18").format(new Random().nextInt(35)));
            holder.name.setText(name);
//            holder.location.setText(location);
        } else {

        }
//        holder.name.setText(chatRoomModel.getText());
        Picasso.get().load(chatRoomModel.getImg()).into(holder.img_girl);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = context.getSharedPreferences("login", Context.MODE_PRIVATE).edit();
                editor.putString("video", chatRoomModel.getVideo());
                editor.putString("image", chatRoomModel.getImg());
                editor.putString("name", holder.name.getText().toString());
                editor.commit();
                Intent intent = new Intent(context, chat_activity.class);
                context.startActivity(intent);
            }
        });
    }


//    private Boolean checkPermission() {
//        if (ContextCompat.checkSelfPermission(this.context, "android.permission.CAMERA") != 0) {
//            return false;
//        }
//        return true;
//    }
//
//    private Void requestPermission() {
//        ActivityCompat.requestPermissions(, new String[]{"android.permission.CAMERA"}, PERMISSION_REQUEST_CODE);
//        return null;
//    }

//    public int getResourceID(String str, String str2, Context context2) {
//        int identifier = context2.getResources().getIdentifier(str, str2, context2.getApplicationInfo().packageName);
//        if (identifier != 0) {
//            return identifier;
//        }
//        throw new IllegalArgumentException("No resource string found with name " + str);
//    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.listData.size();
    }


    public interface ItemClickCallback {
        void onItemClick(int i);
    }

    public class chatRoomHolder extends RecyclerView.ViewHolder {
        ImageView img_girl;
        private LinearLayout container;
        private TextView name;

        public chatRoomHolder(View view) {
            super(view);
            name = (TextView) view.findViewById(R.id.text_place);
            container = (LinearLayout) view.findViewById(R.id.cont_item_root);
            img_girl = (ImageView) view.findViewById(R.id.img_girl);
        }
    }
}
