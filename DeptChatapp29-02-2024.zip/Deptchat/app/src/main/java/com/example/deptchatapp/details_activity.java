package com.example.deptchatapp;

import static com.unity3d.services.core.properties.ClientProperties.getActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.deptchatapp.Ads.BannerAds;
import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.Random;

public class details_activity extends AppCompatActivity {


    String video;
    private boolean isFavorite = false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BannerAds bannerAds =new BannerAds(this);

        bannerAds.interstitialads(details_activity.this);

        setContentView(R.layout.activity_details);
        TextView connectnow = findViewById(R.id.connectnow);
        TextView id = findViewById(R.id.userid);
        ImageView backarrow = findViewById(R.id.backarrow);
        ToggleButton toggleFavorite = findViewById(R.id.toggleFavorite);
        CardView messagebutton = findViewById(R.id.messagebutton);
        TextView permincharge = findViewById(R.id.permincharge);
        toggleFavorite.setTextOff("");
        toggleFavorite.setTextOn("");




        SharedPreferences preferences = getSharedPreferences("login", MODE_PRIVATE);
        int perminchargetext = preferences.getInt("perminchage", 0);
        permincharge.setText(perminchargetext + "/min");


        TextView name = findViewById(R.id.name);
        TextView age = findViewById(R.id.age);
        ImageView imagefull = findViewById(R.id.fullimageview);
        ImageView menu = findViewById(R.id.menu);
        ImageView shortimage = findViewById(R.id.shortimageview);



        name.setText(preferences.getString("name",null));
        age.setText(preferences.getString("age",null));
        String imageurl = preferences.getString("image",null);
        Picasso.get().load(imageurl).into(imagefull);
        Picasso.get().load(imageurl).into(shortimage);

        video = preferences.getString("video",null);

        id.setText(new DecimalFormat("000000000").format(new Random().nextInt(999999999)));


        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                diamond_bottomsheet bottomsheet = new diamond_bottomsheet();

                bottomsheet.show(getSupportFragmentManager(), bottomsheet.getTag());
            }
        });
        toggleFavorite.setChecked(isFavorite);
        toggleFavorite.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Toggle the favorite status
                isFavorite = isChecked;

                // You can perform additional actions here based on the favorite status

                // For example, show a message
                if (isFavorite) {
                    // Item is now a favorite
                    toggleFavorite.setBackgroundResource(R.drawable.favoritered);
                } else {
                    // Item is no longer a favorite
                    toggleFavorite.setBackgroundResource(R.drawable.favorite);
                }
            }
        });


        messagebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(details_activity.this, chat_activity.class);
                startActivity(intent);
            }
        });
        backarrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        connectnow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences preferences = getSharedPreferences("login", MODE_PRIVATE);
                int permincharge = preferences.getInt("perminchage", 0);
                int availablecoin = preferences.getInt("coins", 0);

                if (availablecoin >= permincharge && availablecoin != 0) {
                    Intent intent = new Intent(details_activity.this, ConnectionVideoActivity.class);
                    intent.putExtra("video", video);
                    startActivity(intent);
                }
                else
                {
                    Intent intent = new Intent(details_activity.this, plan_activity.class);
                    startActivity(intent);
                }

            }
        });
    }

}