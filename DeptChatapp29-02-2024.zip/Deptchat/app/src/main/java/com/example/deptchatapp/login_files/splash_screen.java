package com.example.deptchatapp.login_files;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.deptchatapp.Ads.ApiInterface;
import com.example.deptchatapp.Ads.ApiWebServices;
import com.example.deptchatapp.Ads.SammanNidhiAdsModel;
import com.example.deptchatapp.MainActivity;
import com.example.deptchatapp.R;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.gson.Gson;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class splash_screen extends AppCompatActivity {

    ProgressBar progressBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        progressBar = findViewById(R.id.progressBar2);
        SharedPreferences editor = getSharedPreferences("login", MODE_PRIVATE);
       int clientid = editor.getInt("clientid",0);

       if (clientid==0)
       {
           startActivity(new Intent(splash_screen.this, MainActivity.class));
           finish();

       }

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(splash_screen.this, start_activity.class));
                finish();
            }
        }, 2000);

    }

}