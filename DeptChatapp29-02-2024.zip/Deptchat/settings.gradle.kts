pluginManagement {
    repositories {
        google()
        mavenCentral()
        maven ("https://maven.google.com")
        gradlePluginPortal()
        jcenter()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        maven ("https://jitpack.io")
        jcenter()
    }
}

rootProject.name = "DeptChatapp"
include(":app")
