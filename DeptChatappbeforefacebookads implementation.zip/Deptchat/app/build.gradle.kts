plugins {
    id("com.android.application")
}


android {
    namespace = "com.example.deptchatapp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.deptchatapp"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {


    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("com.google.android.gms:play-services-ads-lite:22.6.0")
    implementation("com.google.firebase:firebase-common:20.4.2")
    implementation("com.google.ads.interactivemedia.v3:interactivemedia:3.32.0")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")

    // retrofit api
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")


    // camera view to add layout
    implementation("androidx.camera:camera-core:1.3.1")
    implementation("androidx.camera:camera-camera2:1.3.1")
    implementation("androidx.camera:camera-view:1.3.1")
    implementation("androidx.camera:camera-lifecycle:1.3.1")

    // lotties animation dependency
    implementation("com.airbnb.android:lottie:6.3.0")

    // circle image dependency
    implementation("de.hdodenhof:circleimageview:3.1.0")
    implementation("com.github.bumptech.glide:glide:4.16.0")

    // payments intigration
    implementation("dev.shreyaspatil.EasyUpiPayment:EasyUpiPayment:3.0.3")

    //ads dependency
//    implementation ("com.facebook.android:audience-network-sdk:7.3.0")
    implementation("com.google.android.gms:play-services-ads:22.6.0")
//    implementation("com.facebook.android:facebook-android-sdk:16.1.3")
    implementation ("com.github.smarteist:autoimageslider:1.4.0")

    implementation("com.applovin:applovin-sdk:12.1.0")
    implementation("com.intuit.sdp:sdp-android:1.0.4")
    implementation("com.google.guava:guava:30.1-jre")
    implementation("androidx.browser:browser:1.7.0")
    implementation("com.squareup.picasso:picasso:2.71828")


    implementation ("org.jetbrains.kotlin:kotlin-stdlib:1.9.22")
//    implementation ("com.google.android.gms:play-services-measurement-sdk-api:21.5.1")
    implementation ("com.facebook.android:facebook-android-sdk:16.1.3")
    implementation("androidx.annotation:annotation:1.7.1")
    implementation (files("libs/unity-ads.aar"))

    implementation ("androidx.lifecycle:lifecycle-viewmodel:2.7.0")
    implementation ("androidx.lifecycle:lifecycle-livedata:2.7.0")
    implementation ("androidx.room:room-runtime:2.6.1")
    annotationProcessor ("androidx.room:room-compiler:2.6.1")


//
    implementation ("com.facebook.android:audience-network-sdk:6.16.0")
    implementation ("com.facebook.android:facebook-android-sdk:16.1.3")
//    implementation ("com.onesignal:OneSignal:[5.0.0, 5.99.99]")

    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar"))))


}