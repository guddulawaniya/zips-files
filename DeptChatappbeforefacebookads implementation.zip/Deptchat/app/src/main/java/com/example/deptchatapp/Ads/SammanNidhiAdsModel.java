package com.example.deptchatapp.Ads;

public class SammanNidhiAdsModel {
    private String id;
    private String appId;
    private String appLovinAppKey;
    private String bannerTop;
    private String bannerTopAdNetwork;
    private String bannerBottom;
    private String bannerBottomAdNetwork;
    private String interstitial;
    private String interstitalAdNetwork;
    private String nativeAd;
    private String nativeAdNetwork;
    private String nativeType;
    private String rewardAdNetwork;
    private String rewardAd;
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public String getAppLovinAppKey() {
        return appLovinAppKey;
    }
    public void setAppLovinAppKey(String appLovinAppKey) {
        this.appLovinAppKey = appLovinAppKey;
    }
    public String getBannerTop() {
        return bannerTop;
    }
    public void setBannerTop(String bannerTop) {
        this.bannerTop = bannerTop;
    }
    public String getBannerTopAdNetwork() {
        return bannerTopAdNetwork;
    }
    public void setBannerTopAdNetwork(String bannerTopAdNetwork) {
        this.bannerTopAdNetwork = bannerTopAdNetwork;
    }
    public String getBannerBottom() {
        return bannerBottom;
    }
    public void setBannerBottom(String bannerBottom) {
        this.bannerBottom = bannerBottom;
    }
    public String getBannerBottomAdNetwork() {
        return bannerBottomAdNetwork;
    }
    public void setBannerBottomAdNetwork(String bannerBottomAdNetwork) {
        this.bannerBottomAdNetwork = bannerBottomAdNetwork;
    }
    public String getInterstitial() {
        return interstitial;
    }
    public void setInterstitial(String interstitial) {
        this.interstitial = interstitial;
    }
    public String getInterstitalAdNetwork() {
        return interstitalAdNetwork;
    }
    public void setInterstitalAdNetwork(String interstitalAdNetwork) {
        this.interstitalAdNetwork = interstitalAdNetwork;
    }
    public String getNativeAd() {
        return nativeAd;
    }
    public void setNativeAd(String nativeAd) {
        this.nativeAd = nativeAd;
    }
    public String getNativeAdNetwork() {
        return nativeAdNetwork;
    }
    public void setNativeAdNetwork(String nativeAdNetwork) {
        this.nativeAdNetwork = nativeAdNetwork;
    }
    public String getNativeType() {
        return nativeType;
    }
    public void setNativeType(String nativeType) {
        this.nativeType = nativeType;
    }
    public String getRewardAdNetwork() {
        return rewardAdNetwork;
    }
    public void setRewardAdNetwork(String rewardAdNetwork) {
        this.rewardAdNetwork = rewardAdNetwork;
    }
    public String getRewardAd() {
        return rewardAd;
    }
    public void setRewardAd(String rewardAd) {
        this.rewardAd = rewardAd;
    }}
