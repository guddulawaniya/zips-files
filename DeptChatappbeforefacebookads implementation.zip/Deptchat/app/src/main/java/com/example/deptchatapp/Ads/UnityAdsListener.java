package com.example.deptchatapp.Ads;

import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.UnityAds;

public class UnityAdsListener implements IUnityAdsLoadListener {

    @Override
    public void onUnityAdsAdLoaded(String placementId) {

    }

    @Override
    public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) {

    }
}
