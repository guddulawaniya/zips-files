package com.example.deptchatapp.Fragments;

import static com.example.deptchatapp.sqllite.messageHelper.TABLE_NAME;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.deptchatapp.Adapters.YourDataModel;
import com.example.deptchatapp.Adapters.favoratemodule;
import com.example.deptchatapp.Adapters.historyshowAdapter;
import com.example.deptchatapp.Adapters.maineAdapter;
import com.example.deptchatapp.Ads.ApiService;
import com.example.deptchatapp.R;
import com.example.deptchatapp.chatroom.ChatRoomAdapter;
import com.example.deptchatapp.chatroom.ChatRoomModel;
import com.example.deptchatapp.chatroom.onclick;
import com.example.deptchatapp.show_history_record;
import com.example.deptchatapp.sqllite.favorateHalper;
import com.example.deptchatapp.sqllite.messageHelper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class message_fragment extends Fragment {

    ArrayList<favoratemodule> chatroom = new ArrayList<>();
    LinearLayout nodatafound;
    private RecyclerView recView;
    String img, video, name, city;
    Cursor partydb;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_message_fragment, container, false);
        CardView call_history = view.findViewById(R.id.call_history);
        CardView likecard = view.findViewById(R.id.likecard);
        nodatafound = view.findViewById(R.id.nodatafound);
        recView = view.findViewById(R.id.chatrecyclerview);

        call_history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), show_history_record.class);
                intent.putExtra("title", "Call history");
                startActivity(intent);
            }
        });

        SharedPreferences preferences = getContext().getSharedPreferences("login",getContext().MODE_PRIVATE);

        boolean checksms = preferences.getBoolean("checksms",false);

        if (checksms)
        {
//            helperdb = new messageHelper(getContext());
            favoratelist();
            nodatafound.setVisibility(View.GONE);
        }
        else
        {
            nodatafound.setVisibility(View.VISIBLE);

        }

        likecard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), show_history_record.class);
                intent.putExtra("title", "I like");
                startActivity(intent);
            }
        });


//        favoratelist();
//        if (tablecheck) getdata();




        return view;
    }


//    void getdata() {
//        favorateHalper helper = new favorateHalper(getContext());
//        SQLiteDatabase database = helper.getWritableDatabase();
//        String query = "select * from " + TABLE_NAME;                               //Sql query to  retrieve  data from the database
//        Cursor cursor = database.rawQuery(query, null);
//
//        if (cursor != null && cursor.moveToNext()) {
//            do {
//                String name = cursor.getString(1);
//                String image = cursor.getString(2);
//                String video = cursor.getString(3);
//                chatroom.add(new favoratemodule(name, image, video));
//
//
//            } while (cursor.moveToNext());
//
//        }
//        ChatRoomAdapter adapter = new ChatRoomAdapter(chatroom, getContext());
//        recView.setLayoutManager(new LinearLayoutManager(getContext()));
//        recView.setAdapter(adapter);
//    }


    public void favoratelist() {

        partydb = new favorateHalper(getContext()).getdata();
        if (partydb != null && partydb.moveToNext()) {
            do {
                String name = partydb.getString(1);
                String image = partydb.getString(2);
                String video = partydb.getString(3);
                chatroom.add(new favoratemodule(name, image, video));

            } while (partydb.moveToNext());


            historyshowAdapter history = new historyshowAdapter(chatroom, getContext());
            recView.setAdapter(history);

        }
    }

}

