package com.example.deptchatapp.chatroom;

public interface onclick {
    void btnclick();
}
