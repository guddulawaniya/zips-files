package com.example.deptchatapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.deptchatapp.Adapters.YourDataModel;
import com.example.deptchatapp.Adapters.favoratemodule;
import com.example.deptchatapp.Ads.BannerAds;
import com.example.deptchatapp.sqllite.favorateHalper;
import com.example.deptchatapp.sqllite.messageHelper;
import com.squareup.picasso.Picasso;
import java.text.DecimalFormat;
import java.util.Random;

public class details_activity extends AppCompatActivity {


    String video;

    private static boolean ischeck = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BannerAds bannerAds = new BannerAds(this);

        bannerAds.interstitialads(details_activity.this);

        setContentView(R.layout.activity_details);
        TextView connectnow = findViewById(R.id.connectnow);
        TextView id = findViewById(R.id.userid);
        ImageView backarrow = findViewById(R.id.backarrow);
        ToggleButton toggleFavorite = findViewById(R.id.toggleFavorite);
        CardView messagebutton = findViewById(R.id.messagebutton);
        TextView permincharge = findViewById(R.id.permincharge);
        toggleFavorite.setTextOff("");
        toggleFavorite.setTextOn("");

        if (ischeck)
        {
            toggleFavorite.setBackgroundResource(R.drawable.favoritered);
        }
        else {

            toggleFavorite.setBackgroundResource(R.drawable.favorite);

        }
        SharedPreferences preferences = getSharedPreferences("login", MODE_PRIVATE);
        int perminchargetext = preferences.getInt("perminchage", 0);
        permincharge.setText(perminchargetext + "/min");


        TextView name = findViewById(R.id.name);
        TextView age = findViewById(R.id.age);
        ImageView imagefull = findViewById(R.id.fullimageview);
        ImageView menu = findViewById(R.id.menu);
        ImageView shortimage = findViewById(R.id.shortimageview);


        String nametext = preferences.getString("name", null);
        name.setText(nametext);
        age.setText(preferences.getString("age", null));
        String imageurl = preferences.getString("image", null);


        Picasso.get().load(imageurl).into(imagefull);
        Picasso.get().load(imageurl).into(shortimage);



        video = preferences.getString("video", null);




        id.setText(new DecimalFormat("000000000").format(new Random().nextInt(999999999)));


        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                diamond_bottomsheet bottomsheet = new diamond_bottomsheet();

                bottomsheet.show(getSupportFragmentManager(), bottomsheet.getTag());
            }
        });


        toggleFavorite.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
//                    favorateHalper Helper = new favorateHalper(details_activity.this);
                    ischeck = isChecked;
                    favoratemodule model = new favoratemodule(nametext,imageurl,video);
//                    Helper.insertdata(model);
                    toggleFavorite.setBackgroundResource(R.drawable.favoritered);

                } else {
//                    favorateHalper Helper = new favorateHalper(details_activity.this);
                    ischeck = isChecked;
//                    Helper.deleteRowWithCondition(nametext);
                    toggleFavorite.setBackgroundResource(R.drawable.favorite);
                }
            }
        });


        messagebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = getSharedPreferences("login",MODE_PRIVATE).edit();
                editor.putBoolean("checksms",true);
                editor.commit();

//                messageHelper messageHelper = new messageHelper(details_activity.this);
//
//                favoratemodule model = new favoratemodule(nametext,imageurl,video);
//                messageHelper.insertdata(model);

                Intent intent = new Intent(details_activity.this, chat_activity.class);
                startActivity(intent);
            }
        });
        backarrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        connectnow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences preferences = getSharedPreferences("login", MODE_PRIVATE);
                int permincharge = preferences.getInt("perminchage", 0);
                int availablecoin = preferences.getInt("coins", 0);

                if (availablecoin >= permincharge && availablecoin != 0) {
                    Intent intent = new Intent(details_activity.this, ConnectionVideoActivity.class);
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(details_activity.this, plan_activity.class);
                    startActivity(intent);
                }

            }
        });
    }

}