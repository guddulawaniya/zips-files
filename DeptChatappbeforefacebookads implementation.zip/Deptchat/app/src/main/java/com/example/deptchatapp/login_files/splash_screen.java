package com.example.deptchatapp.login_files;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

import com.example.deptchatapp.MainActivity;
import com.example.deptchatapp.R;


public class splash_screen extends AppCompatActivity {

    ProgressBar progressBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        progressBar = findViewById(R.id.progressBar2);
        SharedPreferences editor = getSharedPreferences("login", MODE_PRIVATE);
        int clientid = editor.getInt("clientid", 0);

//
//        if (clientid != 0) {
//            startActivity(new Intent(splash_screen.this, MainActivity.class));
//            finish();
//
//        } else {
//

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    startActivity(new Intent(splash_screen.this, start_activity.class));
                    finish();
                }
            }, 2000);

//        }

    }

}