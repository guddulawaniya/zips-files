package com.example.deptchatapp.login_files;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.deptchatapp.Ads.BannerAds;
import com.example.deptchatapp.MainActivity;
import com.example.deptchatapp.R;
import com.example.deptchatapp.RingtonePlayer;
import com.example.deptchatapp.privacy_activity;
import com.example.deptchatapp.privacyplocy;
import com.google.ads.interactivemedia.v3.api.Ad;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MediaAspectRatio;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;

import java.text.DecimalFormat;
import java.util.Random;

public class start_activity extends AppCompatActivity {

    AdView bannerview;
    FrameLayout banneradtemplete;

    FrameLayout bannerframlayout,nativead, nativeframlaout, nativeframlaout2;
    AdView mAdView ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);


//        google ads (bannerframlayout);
        mAdView = findViewById(R.id.adView);
        nativead = findViewById(R.id.nativead);

        // banner ads called
         BannerAds bannerAds =new BannerAds(this);
         bannerAds.BnnersAdview(mAdView);

        bannerAds.interstitialads(start_activity.this);




        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.POST_NOTIFICATIONS},
                        67798);
            }
        }


        TextView nextbutton = findViewById(R.id.nextbutton);
        TextView termcondition = findViewById(R.id.termcondition);
        TextView privacytextview = findViewById(R.id.privacy);

        termcondition.setPaintFlags(termcondition.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        privacytextview.setPaintFlags(privacytextview.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

        termcondition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(start_activity.this, privacy_activity.class);
                startActivity(intent);
            }
        });
        privacytextview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(start_activity.this, privacyplocy.class);
                startActivity(intent);
            }
        });


        SharedPreferences preferences = getSharedPreferences("login", MODE_PRIVATE);
        boolean adsclose = preferences.getBoolean("closeads",true);

        nextbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String userid = new DecimalFormat("000000").format(new Random().nextInt(999999));

                SharedPreferences.Editor editor = getSharedPreferences("login", MODE_PRIVATE).edit();
                editor.putInt("clientid", Integer.parseInt(userid));
                editor.commit();

                startActivity(new Intent(start_activity.this, MainActivity.class));
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        // Destroy the AdView when the activity is destroyed to release resources
        if (mAdView != null) {
            mAdView.destroy();
        }
        super.onDestroy();
    }
}