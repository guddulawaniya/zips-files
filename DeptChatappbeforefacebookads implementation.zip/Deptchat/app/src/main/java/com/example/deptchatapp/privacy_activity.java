package com.example.deptchatapp;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;


public class privacy_activity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy);


    }

}