package com.example.deptchatapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.deptchatapp.Adapters.YourDataModel;
import com.example.deptchatapp.Adapters.favoratemodule;
import com.example.deptchatapp.Adapters.historyshowAdapter;
import com.example.deptchatapp.chatroom.ChatRoomAdapter;
import com.example.deptchatapp.sqllite.favorateHalper;

import java.util.ArrayList;
import java.util.List;

public class show_history_record extends AppCompatActivity {

    List<favoratemodule> list;
    Cursor partydb;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_history_record);

        Intent intent = getIntent();
        recyclerView = findViewById(R.id.recycler_view);

        TextView title = findViewById(R.id.titletext);
        title.setText(intent.getStringExtra("title"));
        ImageView backarrow = findViewById(R.id.backarrow);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        list = new ArrayList<>();

        favoratelist();

        backarrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    public void favoratelist() {
        partydb = new favorateHalper(show_history_record.this).getdata();

        if (partydb != null && partydb.moveToNext()) {
            do {
                String name = partydb.getString(1);
                String image = partydb.getString(2);
                String video = partydb.getString(3);
                list.add(new favoratemodule(name, image, video));


            } while (partydb.moveToNext());


            historyshowAdapter history = new historyshowAdapter(list, this);
            recyclerView.setAdapter(history);
        }


    }
}