package com.example.complain_close_flutter;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
