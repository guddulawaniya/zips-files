import 'dart:convert';

import 'package:complain_close_flutter/CustomAutocomplete.dart';
import 'package:complain_close_flutter/CustomTextView.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;

class uploaddata extends StatefulWidget {
  const uploaddata({super.key});

  @override
  State<uploaddata> createState() => _uploaddataState();
}

class _uploaddataState extends State<uploaddata> {
  List<dynamic> dataList = [];
  late int indexshow;

  @override
  void initState() {
    super.initState();
    fetchData(); // Fetch data when widget initializes
  }

  Future<void> fetchData() async {
    const url =
        'https://dummy-crm.raghaw.in/api/get_item_details_close.php?complaint_id=SM202401';
    // final url = 'https://dummy-crm.raghaw.in/api/get_item_details_close.php?complaint_id=SM202423722';

    try {
      print('Fetching data from: $url');
      final response = await http.get(Uri.parse(url));

      print('Response status code: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        Fluttertoast.showToast(msg: "Successfully fetched data");
        setState(() {
          dataList = json.decode(response.body);
        });
      } else {
        Fluttertoast.showToast(
            msg: "Error: ${response.statusCode}",
            toastLength: Toast.LENGTH_LONG);
        throw Exception('Failed to load data');
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "Catch Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Update Complaint',
          style: TextStyle(fontSize: 14),
        ),
      ),
      body: Flexible(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Flexible(
              child: SingleChildScrollView(
                child: Container(
                  margin: const EdgeInsets.only(left: 16, right: 16),
                  child: Column(
                    children: [
                      Card.outlined(
                        elevation: 5,
                        surfaceTintColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: const BorderSide(
                            color: Colors.grey, // Specify the border color here
                            width: 1.0, // Specify the border width here
                          ),
                        ),
                        child: Container(
                          margin: const EdgeInsets.all(10),
                          child: const Column(
                            children: [
                              CustomAutocomplete(
                                  text: 'Group Name', hinttext: 'Select'),
                              CustomAutocomplete(
                                  text: 'Item Name', hinttext: 'Select'),
                              CustomTextView(
                                  text: 'item Quantity',
                                  hinttext: 'Enter Quantity'),
                              CustomTextView(
                                  text: 'Serial No',
                                  hinttext: 'Enter Serial No'),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 15),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Flexible(
                            child: Container(
                                padding: const EdgeInsets.only(
                                    left: 6, right: 6, top: 3, bottom: 3),
                                decoration: BoxDecoration(
                                  borderRadius:
                                      const BorderRadius.all(Radius.circular(10)),
                                  border: Border.all(
                                      color: CupertinoColors.systemBlue,
                                      width: 1),
                                ),
                                child: TextButton(
                                  onPressed: () {},
                                  child: const Text(
                                    'Upload Item',
                                    style: TextStyle(
                                        color: Colors.black87, fontSize: 14),
                                  ),
                                )),
                          ),
                          Flexible(
                            child: Container(
                                padding: const EdgeInsets.only(
                                    left: 6, right: 6, top: 3, bottom: 3),
                                decoration: BoxDecoration(
                                  borderRadius:
                                      const BorderRadius.all(Radius.circular(10)),
                                  border: Border.all(
                                      color: CupertinoColors.systemBlue,
                                      width: 1),
                                ),
                                child: TextButton(
                                  onPressed: () {},
                                  style: const ButtonStyle(),
                                  child: const Text(
                                    'View Item',
                                    style: TextStyle(
                                        color: Colors.black87, fontSize: 14),
                                  ),
                                )),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      Column(
                        children: [
                          SizedBox(
                              width: double.infinity,
                              height: double.tryParse('200'),
                              child: dataList.isEmpty
                                  ? const Center(child: CircularProgressIndicator())
                                  : ListView.builder(
                                      itemCount: dataList.length,
                                      itemBuilder: (context, index) {
                                        indexshow = index;
                                        indexshow++;
                                        return Card(
                                          elevation: 3,
                                          surfaceTintColor: Colors.white,
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              side: const BorderSide(
                                                  color: Colors.grey,
                                                  width: 1)),
                                          child: Container(
                                            padding: const EdgeInsets.all(10),
                                            child: Text('$indexshow. ' +
                                                dataList[index]['item_name']),
                                          ),
                                        );
                                      },
                                    )),
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Container(
              margin: const EdgeInsets.only(left: 20, right: 20, bottom: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Flexible(
                    child: Container(
                      margin: const EdgeInsets.only(right: 10),
                      width: double.tryParse('300'),
                      child: TextButton(
                          onPressed: () {},
                          style: ButtonStyle(
                              backgroundColor: MaterialStateColor.resolveWith(
                                  (states) => Colors.blue)),
                          child: const Text(
                            'Previous',
                            style: TextStyle(
                                color: CupertinoColors.white, fontSize: 15),
                          )),
                    ),
                  ),
                  Flexible(
                    child: Container(
                      margin: const EdgeInsets.only(left: 10),
                      width: double.tryParse('300'),
                      child: TextButton(
                          onPressed: () {},
                          style: ButtonStyle(
                              backgroundColor: MaterialStateColor.resolveWith(
                                  (states) => Colors.blue)),
                          child: const Text(
                            'Submit',
                            style: TextStyle(
                                color: CupertinoColors.white, fontSize: 15),
                          )),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
